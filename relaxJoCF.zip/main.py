import functions_framework
import logging
import vertexai
from vertexai.preview.language_models import ChatModel, InputOutputTextPair


def fulfillment(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    vertexai.init(project="mygenerativeai", location="us-central1")
    chat_model = ChatModel.from_pretrained("chat-bison@001")
    parameters = {
    "temperature": 0.2,
    "max_output_tokens": 992,
    "top_p": 0.8,
    "top_k": 40
}

    # Start a chat session with the model.
    chat = chat_model.start_chat(
        context="Hi Your Name is Jo. You are a Therapist, A relaxation coach who sees live positively and is very hopeful. You help people calm down by talking to them. Help people with relationship conversation. You teach meditation techniques, yoga postures. You can recommend songs and share light-hearted funny jokes. Whenever someone says meditation you teach them to meditate. You also help people build daily time table and lead a healthy life style with receipe recommendations and help people build healthy food habits. You help people calm down by teaching them breathing techniques. You don't talk about politics, religion or sex. You help teenagers with depression talk to you and offer a safe space to trust you.",
        examples=[
            InputOutputTextPair(
                input_text="""Hola""",
                output_text="""Hey! I am Jo. Your Relaxation Coach.. How is your day going so far?"""
            ),
            InputOutputTextPair(
                input_text="""Hey Jo""",
                output_text="""Hi There! How are things looking for you today!"""
            ),
            InputOutputTextPair(
                input_text="""Howdy!""",
                output_text="""Hey! I am Jo. Your Relaxation Coach.. How is your day going so far?"""
            ),
            InputOutputTextPair(
                input_text="""Knock knock!""",
                output_text="""Hi There! How are things looking for you today!"""
            )
        ]
    )
    req = request.get_json()
    #ret = req.get(text)
    print(f'start {req}' );
    usertext = req["text"]
    print(f'usertext is: {usertext}');
    gettext = chat.send_message(usertext)
    #print(f"Response from Model: {gettext.text}")
    response = gettext.text
    #res = {"fulfillment_response":{"messages":[{"text":{"text": [response]}}]}}
    res = {"fulfillment_response":{"messages":[{"text":{"text": [response]}}]}}
    # Return the response.
    #print(f'{gettext}' );
    return res
    #return usertext