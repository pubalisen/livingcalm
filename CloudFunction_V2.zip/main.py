import functions_framework
import logging
import vertexai
import re
from vertexai.preview.language_models import ChatModel, InputOutputTextPair
from pexels_api import API
# Type your Pexels API
PEXELS_API_KEY = '03LdGFPv6KNY3e7KqHWZOa9HNGE1IMIZ1f9Tr5gzHDpBlj659zY9316j'
# Create API object
pexelsapi = API(PEXELS_API_KEY)


def fulfillment(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    vertexai.init(project="mygenerativeai", location="us-central1")
    chat_model = ChatModel.from_pretrained("chat-bison@001")
    parameters = {
        "temperature": 0.2,
        "max_output_tokens": 1024,
        "top_p": 0.8,
        "top_k": 40,
    }

    # Start a chat session with the model.
    chat = chat_model.start_chat(
        context="""Hi Your Name is Jo. You are a relaxation coach who sees live positively and is very hopeful. You help people calm down by talking to them. Help people with relationship conversation. You teach meditation techniques, yoga postures. You can recommend songs and share light-hearted funny jokes. Whenever someone says meditation you teach them to meditate by sharing information. You also help people build daily time table and lead a healthy life style with food recommendations and help people build healthy food habits. You help people calm down by teaching them breathing techniques. You don\'t talk about politics, religion or sex. You help teenagers with depression by talking to them as a counselor and offer a safe space to trust you. 
As a calming relaxation coach you also share images and photos on topics related to relaxation and happiness sometimes. Complete your response within 1000 characters.

if someone ask\'s you for meditation link please share any of the following links: 
https://www.youtube.com/watch?v=mftERRHclqc
https://youtu.be/_kT38XB1YHo
https://www.youtube.com/live/TdK2yxhATdQ?feature=share

for Yoga  when someone asks for a video share any of the following videos only
https://youtu.be/bJJWArRfKa0
https://youtu.be/H72OjF8QlfU
https://youtu.be/EvMTrP8eRvM

for breathing exercises share any of the following links when you are asked for links
https://youtu.be/tEmt1Znux58
https://youtu.be/1Dv-ldGLnIY
If people are only asking for voga postures or breathing techniques please don\'t share links. 
As a Coach you recommend songs as music therapy. When sharing links you only share streaming links of the official music video""",
        examples=[
            InputOutputTextPair(
                input_text="""Hola""",
                output_text="""Hey! I am Jo. Your Relaxation Coach.. How is your day going so far?""",
            ),
            InputOutputTextPair(
                input_text="""Hey Jo""",
                output_text="""Hi There! How are things looking for you today!""",
            ),
            InputOutputTextPair(
                input_text="""Howdy!""",
                output_text="""Hey! I am Jo. Your Relaxation Coach.. How is your day going so far?""",
            ),
            InputOutputTextPair(
                input_text="""Knock knock!""",
                output_text="""Hi There! How are things looking for you today!""",
            ),
        ],
    )
    req = request.get_json()
    # ret = req.get(text)
    print(f"start {req}")
    usertext = req["text"]
    print(f"usertext is: {usertext}")
    gettext = chat.send_message(usertext)
    print(f"Response from Model: {gettext}")
    response = gettext.text
    print(f"Response from Model: {response}")
    #askforphoto = re.findall("photo|pic|image|snap|photogrophary|img|photoimage", usr)
    #print(f"ask for photo : {askforphoto}")
    
    cities_record = 'photo|pic|image|snap|photogrophary|img|photoimage'
    matches = re.search(cities_record, usertext, flags=re.IGNORECASE)
    print (f"matches: {matches}")

    url = re.findall(
        "http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+",
        response,
    )
    print(f"url {url}")

    #pexelsapi = API(PEXELS_API_KEY)
    pexelsapi.search((usertext), page=1, results_per_page=1)
    photos = pexelsapi.get_entries()
    print(f"Photos: {photos}")
    for photo in photos:
  # Print photographer
        print('Photographer: ', photo.photographer)
  # Print url
        photos = photo.url
        photosimage = photo.original
        print('Photo url: ', photo.url)
  # Print original size url
        print('Photo original size: ', photo.original)
    #photourl = photos.url

    if (len(url) == 0 and matches == None):
        # res = {"fulfillment_response":{"messages":[{"text":{"text": [response]}}]}}
        res = {"fulfillment_response": {"messages": [{"text": {"text": [response]}}]}}
    elif (len(url) != 0 and matches == None):
        res = res = {
    "fulfillment_response": {"messages":
    [{
        "payload": {
            "richContent": [
                [{
                    "type": "image",
                    "rawUrl": "https://storage.googleapis.com/uslivingcalm.com/assets/images/relax.png",
                    "accessibilityText": "relax photo"
                }],
                [{
        "type": "info",
        "title": [response],
        "image": {
          "src": {
            "rawUrl": "https://example.com/images/logo.png"
          }
        },
        "actionLink": [url]
      }]
            ]
        }
    }]
   }
}
   # Return the response.
    else:
        res = {
    "fulfillment_response": {"messages":
    [{
        "payload": {
            "richContent": [
                [{
                    "type": "image",
                    "rawUrl": [photosimage],
                    "accessibilityText": "Cute Photo"
                }],
                [{
        "type": "info",
        "title": "Click here to view the image in full screen",
        "image": {
          "src": {
            "rawUrl": "https://example.com/images/logo.png"
          }
        },
        "actionLink": [photos]
      }]
            ]
        }
    }]
   }
}
    # print(f'{gettext}' );
    return res
    # return usertext
